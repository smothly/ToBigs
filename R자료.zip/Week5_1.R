c(1,2,3,4,5)  #모두 숫자형으로 이루어진 벡터
c(1,2,3,4,"5")  #마지막 요소가 문자라서 모두 문자로 변환됨.

vec1 <- c(1,2,3,4,5)
vec1
vec1[3]  #3번째 요소 값만 보여줌.
vec1[-3]  #마이너스를 붙일 경우 3번째만 빼고 보여줌.
vec1[1:(length(vec1)-2)]  #vec1 의 총 길이에서 2 개를 뺀 개수만큼 출력
vec1[-1:-3]  #1번에서 3번까지 요소를 뺀 나머지만 출력
vec1[2:4]  #2번째부터 4번째까지의 요소 값
vec1[2] <- 6  #vec1[2] 항목의 값을 6으로 변경
vec1
vec1 <- c(vec1,7)  #벡터에 새로운 내용을 추가할 수도 있음.
vec1
vec1[9] <- 9  # 추가되는 자리 사이에 빈자리가 있어도 용납
vec1

append(vec1,10,after=3)  #3번째 다음 위치에 10을 넣으라는 의미
append(vec1,c(10,11),after=2)
vec2 <- c(1,2,3,3,4,5)
vec2
append(vec2,10,after=3)  #3번째 위치 뒤에 10을 넣음.
append(vec2,11,after=3)  #3번째 위치 뒤에 11을 넣음 (10이 없어짐.)
append(vec2,11,after=0)  #0 은 가장 앞자리라는 의미

c(1,2,3) + c(4,5,6)
c(1,2,3) + 1
var1 <- c(1,2,3)
var2 <- c(3,4,5)
var1 + var2
var3 <- c("3","4",5)  #전부 문자로 바뀐 후 저장
var1 + var3 
union(var1,var3)  #데이터 형이 다를 경우 union을 사용
var4 <- c(1,2,3,4,5)
var1
var4
var1 + var4
var1 - var2

union(var1,var2)
setdiff(var1,var2)  #var1 에 있는데 var2 에 없는 요소 출력
setdiff(var2,var1)  #var2 에 있는데 var1 에 없는 요소 출력
intersect(var1,var2)  #var1 과 var2 에 공통적으로 있는 요소 출력

fruits <- c(10,20,30)
fruits
names(fruits) <- c("apple","banana","peach")  #names() 함수 써서 벡터의 각 칼럼(요소)에 이름 지정 가능
fruits

var5 <- seq(1,5) ; var5
var6 <- seq(2,-2) ; var6
var7 <- seq(1,10,2) ; var7  #2씩 증가시키면서 값을 할당
var8 <- seq(1,10,length.out=5) ; var8  #5등분

var9 <- rep(c(1,2,3),2) ; var9
var10 <- rep(1:3,each=3) ; var10
var11 <- rep(1:3, 2, each=3); var11

3 %in% var7  #var7 에서 3 이 있는지 검색함.
4 %in% var7  #var7 에서 4 가 있는지 검색함.