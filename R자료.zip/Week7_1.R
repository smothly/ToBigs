setwd("C:\\R_temp")  #데이터가 있는 작업용 디렉터리를 설정
getwd()
list.files( )  #setwd 설정되어 있는 곳의 파일을 불러옴.
head(list.files())  #head()는 처음 6개의 값만 반환
tail(list.files(), n=3)  #tail()은 끝 6개의 값만 반환, 갯수 지정 가능  
list.files(recursive=T)  #하위 디렉토리 내용까지 전부 불러옴.
list.files(all.files=T)  #숨김 파일까지 전부 불러옴.

scan1 <- scan("scan_1.txt")  #scan1 변수에 저장 - 모두 정수 
scan1

#Q1) scan1을 굳이 정수형 벡터로 저장하고 싶으면? scan1 <- as.integer(scan1); scan1 or scan1 <- scan("scan_1.txt", what=integer(0)); scan1

scan2 <- scan('scan_2.txt')  #scan2 변수에 저장 - 모두 실수
scan2
scan2 <- scan('scan_2.txt',n=3) ;scan2 #3개값만 불러옴.
scan2 <- scan('scan_2.txt',nlines=2) ;scan2 #두 줄의 값만 불러옴.

#Q2) scan2를 굳이 실수형 벡터로 소수점 둘째자리까지 나타내고 싶으면? scan_2.txt파일을 수정하고 다시시도!(예: 1.00 -> 1.01)

scan3 <- scan('scan_3.txt'); scan3
scan3 <- scan('scan_3.txt',what=""); scan3  #문자형으로 데이터 불러옴. character(0)도 가능 
scan4 <- scan('scan_4.txt'); scan4
scan4 <- scan('scan_4.txt',what=character(0)); scan4 

#Q3) scan4를 굳이 문자, 문자, 정수, 실수의 형태로 불러오고 싶으면?
#scan5 <- scan("scan_4.txt", what=list("","",integer(0),numeric(0))) ;scan5
#scan6 <- scan("scan_4.txt", what=list(S_ID="",NAME="",RANK=integer(0),SCORE=numeric(0))); scan6
#scan7 <- data.frame(scan6, stringsAsFactors = F); scan7

scan()  #숫자 직접 입력 (예: 1 2 3 + 4 5 + 6 + Enter) 
input <- scan( )  #input변수에 저장 (예: 1 + 2 + 3 + Enter)
input
input2 <- scan(what="")  #문자 입력 받을 때는 what="" 사용 (예: a + b + Enter)
input2

scan("fruits_2.txt", what="")
scan("fruits_3.csv", what="")
scan("fruits_3.csv", what="", sep=",")

readline()  # 1 2 3 - 이렇게 입력 후 엔터
input3 <- readline()  #R is very fun! - 이렇게 입력 후 엔터 
input3
input4 <- readline("Are you OK? : ")  #화면에 원하는 글자를 출력한 후 입력을 받을 수도 있음. - Yes! 입력
input4

input5 <- readLines("scan_4.txt")
input5
input5 <- readLines("scan_4.txt", n=3)
input5
input6 <- readLines("scan_5.txt")
input6

fruits <- read.table('fruits.txt')
fruits
fruits <- read.table('fruits.txt',header=T, stringsAsFactors = F)  #header가 있다고 알려줌. #factor형 대신 character형 저장을 원할경우!
fruits
str(fruits)

#Q4) read.table()로 scan_4.txt 파일을 불러올 수 있을까? 있다면 class는?
#read.table("scan_4.txt")
#class(read.table("scan_4.txt"))

fruit2 <- read.table('fruits_2.txt')  #주석은 자동 제외
fruit2
fruit2 <- read.table('fruits_2.txt',skip=2)  #건너 뛸 줄 수를 지정
fruit2
fruit2 <- read.table('fruits_2.txt',nrows=2)  #출력할 줄 수를 지정
fruit2

# 만약 큰 파일이 있어서 일부만 먼저 불러오고 나머지는 다시 로딩할 경우 위 두 가지 옵션을 적절히 사용
fruits3 <- read.table('fruits.txt',header=T,nrows=2)
fruits3
fruits4 <- read.table('fruits.txt',header=F,skip=3,nrows=2)
fruits4

#Q5) fruits3과 fruits4 변수를 붙이려면?
#names(fruits4) <- c("no", "name", "price", "qty")
#fruits5 <- rbind(fruits3, fruits4)
#fruits5

fruit3 <- read.csv('fruits_3.csv')
fruit3

#Q6) read.table()을 사용하여 fruits_3.csv 파일을 불러오려면?
#fruit33 <- read.table('fruits_3.csv', sep=",", header=T)
#fruit33
#class(fruit33)

fruit4 <- read.csv('fruits_4.csv')
fruit4
fruit4 <- read.csv('fruits_4.csv',header=F)
fruit4
label <- c('NO','NAME','PRICE','QTY')
fruit4 <- read.csv('fruits_4.csv',header=F,col.names=label)
fruit4

#Q7) fruit4에 열이름 주는 다른 방법은?
#colnames(fruit4)<-c('NO','NAME','PRICE','QTY')
#fruit4

#클립보드 사용해서 data frame 형태로 불러오기
#fruits_6.xls 파일을 열고 원하는 부분 복사(ctrl+c)한 후 아래 명령 수행
fruits6 <- read.delim("clipboard")
fruits6

#Q8) read.table()을 사용하여 클립보드 데이터를 불러오려면?
#fruit66 <- read.table("clipboard", sep="\t", header=T)
#fruit66
#class(fruit66)