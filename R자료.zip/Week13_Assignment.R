#BMI계산 및 등급구분
BMI<-function(x,y){
  BMI_index<-round(x/y^2, digits=1)
  BMI_grade<-if(BMI_index<=18.5){
    "저체중"
  } else if(BMI_index<=24.9){
    "정상"
  } else if(BMI_index<=29.9){
    "과체중"
  } else{
    "비만"
  }
  result<-c(BMI_index, BMI_grade)
  names(result)<-c("BMI지수","등급")
  return(result)
}

BMI(89,1.80)
