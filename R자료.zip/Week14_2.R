setwd("C:/c_temp")
getwd()

Student<-read.csv("example_studentlist.csv")
str(Student)
View(Student)
attach(Student)  #생성한 Student 데이터프레임을 메모리에 올려줌으로써 각 칼럼명을 변수명 형태로 사용가능하게 해줌!
#attach() 사용하지 않을 경우, 필드명 사용시 반드시 “Student$age”와 같은 형태로 적어주어야 함! 

##barplot() - 명목형 변수별 빈도, 평균값, 합산 등을 나타내는 그래프
FreqBlood<-table(bloodtype)  #빈도수를 나타내기 위해 table() 함수 이용
FreqBlood
class(FreqBlood)
barplot(FreqBlood)
plot(bloodtype)  #plot 함수로도 위 결과를 나타낼 수 있음.
barplot(FreqBlood, main="혈액형별빈도수", xlab="혈액형", ylab="빈도수")
barplot(FreqBlood, main="혈액형별빈도수", xlab="혈액형", ylab="빈도수", horiz=T)  #옆으로 눕힐수도 있음.
barplot(FreqBlood, main="혈액형별빈도수", xlab="빈도수", ylab="혈액형", horiz=T)

#혈액형별 키의 평균값 구하기
Height<-tapply(height,bloodtype,mean)
Height  #tapply의 결과값은 실제로 "배열"이긴 하지만 "table"모양으로 표현됨.
class(Height)
barplot(Height)
barplot(Height, ylim=c(0,200))  #y축의 범위를 늘려줌.

#Q6) 혈액형별 평균값을 막대그래프 위에 표시하려면?
grid()
text((1:4), rep(180,4), col="red",labels=Height)
text(c(0.7,1.9,3.1,4.3), rep(180,4), col="red",labels=Height) #c > 가로위치, rep 세로위치

#여러 막대 그래프를 그룹으로 묶어서 한꺼번에 출력하기
v1<-c(100,120,140,160,180)
v2<-c(120,130,150,140,170)
v3<-c(140,170,120,110,160)
Fruits_Bar<-data.frame(BANANA=v1,CHERRY=v2,ORANGE=v3)
Fruits_Bar
barplot(Fruits_Bar)  #barplot함수는 데이터프레임을 읽을 수 없음.
barplot(as.matrix(Fruits_Bar))
barplot(as.matrix(Fruits_Bar),beside=T)  #누적하지 않고 옆으로 붙임.
barplot(as.matrix(Fruits_Bar),beside=T, col=rainbow(nrow(Fruits_Bar)))  #무지개색
barplot(as.matrix(Fruits_Bar),beside=T, col=rainbow(nrow(Fruits_Bar)),ylim=c(0,300))
legend("topright", c("A","B","C","D","E"),fill=rainbow(5))

##파이 모양의 그래프 그리기 - 전체 합이 100%가 되는 경우 서로 비교할 때 유용
pie(FreqBlood)
pie(FreqBlood,init.angle=90,clockwise=T,col=c(1,2,3,4))  #위에서 시계방향으로 시작하도록, 색깔도 바꿈.
pct<-round(FreqBlood/sum(FreqBlood)*100,2)  #혈액형별 비율(퍼센트) 구함
pct
lab<-paste(c("A","AB","B","O"),"\n",pct,"%",sep="")  
lab
pie(FreqBlood,init.angle=90,clockwise=T,col=c(1,2,3,4),labels=lab)  #수치값을 함께 출력

##boxplot 그리기 - 데이터의 분포를 상세히 보여주는 그래프로 주식, 통계정보 등에 주로 사용
boxplot(height)
aa<-boxplot(height)
aa  #lower whisker, lower hinge, median, upper hinge, upper whisker 순서로 나타남.
boxplot(bloodtype,height)
boxplot(height~bloodtype)  #정규식으로만 표현됨.
plot(bloodtype, height)  #plot함수로도 표현 가능
bb<-boxplot(height~bloodtype)
bb

##히스토그램 그리기 - 연속형 데이터의 분포를 알아보는데 적합
hist(height)
cc<-hist(height)
cc
hist(height,prob=T)  #빈도 대신 상대도수밀도로 표현
hist(height,freq=F)
#7개 간격으로 나누고 싶을 경우
BreakPoint <- seq(min(height),max(height),length.out=7)  #총 7개의 값
dd<-hist(height,breaks=BreakPoint)  #6개 간격으로 나뉨.
dd
BreakPoint <- seq(min(height),max(height),length.out=8)  #총 8개의 값
ee<-hist(height,breaks=BreakPoint)  #7개 간격으로 나뉨.
ee

##한 화면에 여러 개 그래프 그리기 - par()함수 이용
par(mfrow=c(2,3))  #2행, 3열의 그래프를 분할해서 넣을 수 있음.
plot(age)
plot(height,weight)
barplot(table(bloodtype))
pie(table(bloodtype))
hist(height)
boxplot(height)
par(mfrow=c(1,1))  #원래대로 돌리고 싶으면 반드시 아래와 같이 수행해야 함!

##넘겨가며 그래프 보기
#weight 변수를 y축으로 두고 x축에 다양한 변수를 넘겨가며 보듯이 표현할 수 있음.
plot(weight~height+age+grade+absence+sex)  #각 독립변수별 종속변수와의 관계를 보고 싶을 때 유용 

##두 라인을 겹쳐 비교하는 그래프 그리기 응용
runif(30)  #0~1사이 난수(random한 수) 30개를 만들어라!
TS1<- c(round(runif(30)*100))
TS2<- c(round(runif(30)*100))
TS1
TS2
TS1<-sort(TS1)
TS2<-sort(TS2)
plot(TS1,type="l")
lines(TS2,type="l",lty="dashed", col="red")

##Miscellaneous
# Make an empty chart
plot(1, 1, xlim=c(1,5.5), ylim=c(0,7), type="n", ann=FALSE)

# Plot digits 0-4 with increasing size and color
text(1:5, rep(6,5), labels=c(0:4), cex=1:5, col=1:5)

# Plot symbols 0-4 with increasing size and color
points(1:5, rep(5,5), cex=1:5, col=1:5, pch=0:4)
text((1:5)+0.4, rep(5,5), cex=0.6, 0:4)

# Plot symbols 5-9 with labels
points(1:5, rep(4,5), cex=2, pch=(5:9))
text((1:5)+0.4, rep(4,5), cex=0.6, 5:9)

# Plot symbols 10-14 with labels
points(1:5, rep(3,5), cex=2, pch=(10:14))
text((1:5)+0.4, rep(3,5), cex=0.6, 10:14)

# Plot symbols 15-19 with labels
points(1:5, rep(2,5), cex=2, pch=(15:19))
text((1:5)+0.4, rep(2,5), cex=0.6, 15:19)

# Plot symbols 20-25 with labels
points((1:6)*0.8+0.2, rep(1,6), cex=2, pch=(20:25))
text((1:6)*0.8+0.5, rep(1,6), cex=0.6, 20:25)

# graph types & line types
lines(1:5,rep(0,5),type="p",lty=1)
lines(1:5,rep(0.2,5),type="l",lty=2,col=6)
lines(1:5,rep(0.4,5),type="b",lty=3,col=7)
lines(1:5,rep(0.6,5),type="o",lty=4,col=8)

