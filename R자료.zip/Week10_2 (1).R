##apply 계열함수
mat1 <- matrix(c(1,2,3,4,5,6),nrow=2,byrow=T)
mat1
apply(mat1,1,sum)  #각 행의 합계 구하기
apply(mat1,2,sum)  #각 열의 합계 구하기
apply(mat1[,c(2,3)],2,max)  #2 열과 3 열의 최대값 구하기
install.packages("googleVis")
library(googleVis)
Fruits
str(Fruits)
apply(Fruits[,4:6],2,sum)
class(apply(Fruits[,4:6],2,sum))
apply(Fruits[,4:6],2,summary)
class(apply(Fruits[,4:6],2,summary))

#7) Sales 열 하나에만 적용하여 sum을 구하려면 코드는?
apply(Fruits[4],2,sum) # 키값 있이 적용
sum(Fruits$Sales) # 키값 없이 적용


attach(Fruits)# Fruits를 올려줌
sum(Sales)


list1 <- list(Fruits$Sales)  #Fruits 의 Sales 값만 가져와서 list1 변수에 담음.
list1
list2 <- list(Fruits$Profit)  #Fruits 의 Profit 값만 가져와서 list2 변수에 담음.
lapply(c(list1,list2),max)  #list1 과 list2 에서 max 값을 구해서 list 형태로 출력
sapply(c(list1,list2),max)

lapply(Fruits[,c(4,5)],max)
sapply(Fruits[,c(4,5)],max)
class(lapply(Fruits[,c(4,5)],max))
class(sapply(Fruits[,c(4,5)],max))

tapply(1:10, rep(1,10), sum)
aa<-tapply(1:10, rep(1,10), sum)
class(aa)
str(aa)

tapply(Fruits$Sales,Fruits$Fruit,sum)  #과일이름(Fruit)별로 판매량(Sales)의 합계 구하기
tapply(Fruits$Sales,Fruits$Year,sum)  #년도별로 합계 판매량 구하기 - Year는 numeric이나 기준칼럼역할을 할때는 factor의 역할 수행
bb<-tapply(Fruits$Sales,Fruits$Fruit,sum)
cc<-tapply(Fruits$Sales,Fruits$Year,sum)
class(bb)
class(cc)
str(bb)
str(cc)

vec1 <- c(1,2,3,4,5)
vec2 <- c(10,20,30,40,50)
vec3 <- c(100,200,300,400,500)
mapply(sum,vec1,vec2,vec3)
dd<-mapply(sum,vec1,vec2,vec3)
class(dd)
str(dd)

aggregate(Sales~Year,Fruits,sum)  #년도별로 Sales된 수량을 sum한 결과
aggregate(Sales~Fruit,Fruits,sum)  #Fruit별로 Sales된 수량을 sum한 결과
ee<-aggregate(Sales~Year,Fruits,sum)
ff<-aggregate(Sales~Fruit,Fruits,sum)
class(ee)
class(ff)
str(ee)
str(ff)

aggregate(Sales~Fruit,Fruits,max)  #Fruit별로 가장 많이 Sales 된 수량
aggregate(Sales~Fruit+Year,Fruits,max)  #'+ 추가조건' 형태로 조건을 추가

#8) apply함수를 사용하여 sapply(Fruits,[,c(4,5)],max)의 결과와 같이 나오게 하는 코드는?
sapply(Fruits[,c(4,5)],max)

apply(Fruits[,c(4,5)],2,max)

#9)홀수를 "1" 그룹, 짝수를 "2" 그룹으로 배치하여 각 그룹의 sum을 구하려면 코드는?
tapply(1:10,rep(c(1,2),5),sum)

#10) mapply 함수를 사용하여 7페이지의 apply(Fruits[,4:6],2,summary)의 결과와 같이 나타내려면 코드는?
apply(Fruits[,4:6],2,summary)
mapply(summary,Fruits[,4,6])

sapply(Fruits[,4:6],summary)

#11) tapply()와 aggregate()의 공통점과 차이점은?