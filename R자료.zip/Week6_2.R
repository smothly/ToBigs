no <- c(1,2,3)
name <- c('apple','banana','peach')
price <- c(100,200,300)
df1 <- data.frame(NO=no,NAME=name,PRICE=price)
df1

no <- c(10,20,30)
name <- c('train','car','airplane')
price <- c(1000,2000,3000)
df2 <- data.frame(NO=no,NAME=name, PRICE=price)
df2

df3 <- cbind(df1,df2)
df3
df4 <- rbind(df1,df2)
df4

df1 <- data.frame(name=c('apple','banana','cherry'), price=c(300,200,100))
df2 <- data.frame(name=c('apple','cherry','berry'), qty=c(10,20,30))
df1
df2
merge(df1,df2)  #df1 기준으로 df2와 공통으로 있는 name 컬럼데이터를 출력함.
merge(df1,df2,all=T)   #데이터가 없는 것도 모두 나오게 all=T 옵션 지정함.
merge(df2,df1)  #df2 기준
merge(df2,df1,all=T)   

df1
new <- data.frame(name="mango",price=400); new  #추가할 내용 생성
df1 <- rbind(df1,new)  #rbind로 행을 추가
df1
df1 <- rbind(df1,data.frame(name="berry",price=500))  #이렇게 해도 됨.
df1
df1 <- cbind(df1,data.frame(qty=c(10,20,30,40,50)))   #열 추가하기
df1

no <- c(1,2,3,4,5)
name <- c("서진수","주시현","최경우","이동근","윤정웅")
address <- c("서울","대전","포항","경주","경기")
tel <- c(1111,2222,3333,4444,5555)
hobby <- c("독서","미술","놀고먹기","먹고놀기","노는애감시하기")
member <- data.frame(NO=no,NAME=name,ADDRESS=address,TEL=tel,HOBBY=hobby)
member

member2 <- subset(member,select=c(NO,NAME,TEL))  #특정 컬럼만 지정
member2
member3 <- subset(member,select= -TEL)   #특정 컬럼만 제외
member3
colnames(member3) <- c("번호","이름","주소","취미")  #열 이름 변경
member3

no <- c(1,2,3,4)
name <- c('Apple','Peach','Banana','Grape')
price <- c(500,200,100,50)
qty <- c(5,2,4,7)
sales <- data.frame(NO=no,NAME=name,PRICE=price,QTY=qty)
sales
ncol(sales)
nrow(sales)
names(sales)
rownames(sales)
sales[c(2,3,1),]  #행의 출력 순서 조정, 4행은 안나옴.
dim(sales)
