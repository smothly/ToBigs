##조건식
#입력된 숫자가 양수이든 음수이든 양수로 출력하기
f_plus<-function(x){
  if(x<0){
    return(-x)
  } else{
    return(x)
  }
}
f_plus(1)
f_plus(-1)

#입력된 숫자가 양수이면 제곱으로, 숫자가 0보다 작거나 같으면 0으로 출력하기
mf1<-function(x){
  if(x>0){
    y<-x*x
    return(y)
  } else {
    y<-x*0
    return(y)
  }
}
mf1(2)
mf1(-1)
mf1(0)

#입력된 숫자가 0보다 크면 2배의 값을, 0일 경우 0을, 0보다 작을 경우 - 2 배의 값을 출력하기
mf2<-function(x){
  if(x>0){
    y<-x*2
    return(y)
  } else if(x==0){
    y<-x
    return(y)
  } else{
    y<-x*-2
    return(y)
  }
}
mf2(3)
mf2(0)
mf2(-3)

#1~10까지 정수로 이뤄진 벡터를 각각 홀수/짝수로 표현하기
aa<-c(1:10)
ifelse(aa%%2==0,"짝수","홀수")

#Q1) 입력되는 인수가5보다 클 때는1을, 5보다 작거나 같으면 무조건 0을 출력하는 myf1( )을 생성하시오. 
myf1<-function(a){
  if(a>5){
    return(1)
  } else{
    return(0)
  }
}
myf1(4)
myf1(5)
myf1(6)
myf1(7)

#Q2) 입력되는 인수가양수일 때는1을, 0 혹은 음수일 때는0을 출력하는 myf2( )를 생성하시오. 

myf2<-function(a){
  if(a>0){
    return(1)
  } else{
    return(0)
  }
}
myf2(1)
myf2(-1)

#Q3)두 숫자를 입력해서첫 번째숫자가 두 번째숫자보다 크거나 같을 경우 첫 번째 숫자에서 두 번째숫자를 뺀값을, 두번째 숫자가 첫번째 숫자보다 클 경우 두번째 숫자에서 첫번째 숫자를 뺀값을 출력하는 함수 myf3( )을 생성하시오. 

myf3<-function(a,b){
  if(a>=b){
    return(a-b)
  } else{
    return(b-a)
  }
}
myf3(3,4)
myf3(3,1)

#Q4) 입력값이0보다 작거나 같을 경우0을, 0보다 크고 5보다 작거나 같을 경우 5를, 5보다 클 경우 10을 출력하는 함수 myf4( )를 생성하시오. 

myf4<-function(a){
  if(a<=0){
    print(0)
  } else if(a<=5){
    print(5)
  } else{
    print(10)
  }
}
myf4(-1)
myf4(3)
myf4(6)

#Q5) 사용자에게 두 개의 숫자를 입력 받은후 두 값이 모두 양수일 경우 두 수의 곱을, 두 값 중 하나라도 0이나음수일 경우는 두 수의 합을 출력하는 myf5()를 생성하시오. 
myf5<-function(a,b){
  if(a>0 & b>0){
    c<-a*b
    return(c)
  } else{
    c<-a+b
    return(c)
  }
}
myf5(2,3)
myf5(2,-1)

##반복문
#while 반복문
i<-0
while(i<5){
  print(i)
  i<-i+1
}

#무한루프(infinite loop) 문제 주의
#i<-6
#while(i>5){
 # print(i)
#  i<-i+1
#}

#무한루프 문제 해결 위해 break 적절히 사용

i<-6
while(i>5){
  print(i)
  i<-i+1
  if(i==10){
    break
  }
}

x<-1
while(x<5){
  x<-x+1
  if(x==4){
    break #끝냄.
  }
  print(x)
}

x<-1
while(x<5){
  x<-x+1
  if(x==4){
    next #print(x)를 실행하지 않고 while문의 처음으로 감.
  }
  print(x)
} 

#for 반복문
for(i in 1:5){
  print(i)
}

i<-0
while(i<5){
  i<-i+1
  print(i)
}

for(i in 1:10){
  if(i%%2==0){
    next
  }
  print(i)
}

#Q6) 1~10까지 정수 가운데 짝수만 출력하고 싶으면?
for(i in 1:10){
  if(i%%2==1){
    next
  }
  print(i)
}

#Q7) 같은 결과를 while 반복문을 사용해서 나타내려면?
x<-0
while(x<10){
  x<-x+1
  if(x%%2!=0){
    next
  }
  print(x)
}

#Q8) 사용자에게 숫자를 입력 받은후 1부터 그 숫자까지 연속적인숫자를 출력하는 myf8( )을 생성하시오. 

myf8<-function(x){
  for(i in 1:x){
    print(i)
  }
}
myf8(3)

#Q9) 사용자에게 정수 n 을 입력 받은후 1부터 n까지의 합을 출력하는 myf9( )를 생성하시오. 
myf9<-function(x){
  j<-0
  for(i in 1:x){
    j<-j+i
  }
  print(j)
}
myf9(10)

#Q10) while 반복문을사용하여 5, 10, 15, 20, 25가 출력되도록 하는 코딩결과를 제시하시오. 이결과를for 반복문을사용하여 출력되도록 하는 코딩결과를 제시하시오. 
x<-1
while(x<=5){
  y<-x*5
  print(y)
  x<-x+1
}

for(i in 1:5){
  i<-i*5
  print(i)
}

#Q11) 복리 이율3%를 제공하는 은행상품에 100만원을 입금하였을때, 매년통장의 잔고를 출력하는 myf11()을 생성하시오. 

myf11<-function(x){
  j<-1000000
  for(i in 1:x){
  j<-j*(1.03)
  print(j)
  }
}
myf11(10)

myf11<-function(x){
  for(i in 1:x){
  j<-1000000*(1.03)^i
  print(j)
  }
}
myf11(10)
