install.packages("ggplot2")
install.packages("ggthemes")  ##ggplot2에서 제공해주지 않는 예쁜 theme들을 별도로 모아둔 패키지 
??ggthemes

library("ggplot2")
library("ggthemes")

##ggplot2 패키지 활용 그래프의 예
diamonds
head(diamonds)
data()

#기본ggplot함수+geom_함수+theme_함수로 이뤄짐.
ggplot(data=diamonds, mapping=aes(x=carat,y=price,color=clarity))+  #데이터프레임, aesthetic mapping(x축,y축,모양,크기,색깔 등 미적 요소 매핑)  
  geom_point()+  #실제 그래프 그리는 함수(geometric object 함수)
  theme_wsj()  #미리 디자인된 저수준 그래픽 요소 들의 집합

setwd("C:/R_temp")
getwd()

Student<-read.csv("example_studentlist.csv")
str(Student)
View(Student)
attach(Student)

plot(height)
a<-plot(height)
a  #plot()과 같은 기본 함수는 객체가 담기지 않음(그래프만 그릴 뿐 어떤 값도 반환하지 않음).

g1<-ggplot(diamonds, aes(x=carat,y=price,color=clarity))
g2<-geom_point()
g3<-theme_wsj()
g1
g2
g3
g1+g2+g3  #+로 연결되어 구분하기 쉽고 관리가 편리, 각각 객체에 담아 사용할 수 있어 재사용성 장점 

#반복적으로 코딩하지 않아도 되기 때문에 빠르고 다양하게 시각화 가능
g1+g2+theme_bw()

##geom() 함수: geom_point(), geom_line(), geom_bar(), geom_histogram(), geom_boxplot() 등
gg1<-ggplot(Student,aes(x=height,y=weight,color=bloodtype))
gg1
gg1+geom_point()
gg1+geom_line()
gg1+geom_point()+geom_line()
gg1+geom_point(size=10)+geom_line(size=1)  #gg1에서 정의된 미적표현요소가 geom()함수로 그대로 전달됨.
gg1+geom_point(size=10)+geom_line(mapping=aes(color=sex),size=1)  #미적표현요소는 geom()함수에서 overwrite가능
gg1+geom_point(size=10)+geom_line(size=1)+facet_grid(.~sex)  #facet_grid()함수는 명목형 변수를 기준으로 별도의 그래프를 그리게 해줌.
coplot(weight~height|sex)

##막대그래프
plot(bloodtype)
barplot(table(bloodtype))
ggplot(Student,aes(x=bloodtype))+geom_bar()  #geom_bar는 table()함수 사용하지 않아도 알아서 빈도를 나타내어 줌.
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar()  #성별로 막대의 컬러가 나타남.
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar(position="dodge")  #성별로 각각 막대로 나타냄.
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar(position="identity")  #누적되지 않고 겹쳐서 나타남.
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar(position="fill")  #전체를 채우는 막대로 나타남.
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar(position="stack")  #default
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar(position="dodge",width=0.5)  #막대의 넓이 값 조정
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar(position="dodge",width=0.5)+labs(x="혈액형",y="빈도")

##Q1)파이 차트는 어떻게 그리나? geom_pie()?
?geom_pie
??geom_pie

ggplot(Student,aes(x=bloodtype))+geom_bar()+coord_polar(theta="x",0,1)
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar()+coord_polar(theta="x")  
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar(width=1)+coord_polar(theta="x")  
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar(width=1,color=1)+coord_polar(theta="x")  
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar(position="dodge",color=1)+coord_polar(theta="x")
ggplot(Student,aes(x=bloodtype,fill=sex))+geom_bar(position="dodge",color=1)+coord_polar(theta="x")+
  scale_x_discrete("")  #x축 이름 삭제

## Aligning labels and bars (라벨넣는 방법) - http://docs.ggplot2.org/current/geom_text.html
df <- data.frame(x=factor(c(1, 1, 2, 2)),y=c(1, 3, 2, 1),grp=c("a","b","a","b"))

# ggplot2 doesn't know you want to give the labels the same virtual width
# as the bars:
ggplot(data = df, mapping=aes(x, y, fill = grp, label = y)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_text(position = "dodge")

# So tell it:
ggplot(data = df, aes(x, y, fill = grp, label = y)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_text(position = position_dodge(0.9))
?position_dodge

##히스토그램
gg2<-ggplot(diamonds, aes(x=carat))
gg2+geom_histogram(binwidth=0.1,fill="orange")  #hist()함수의 breaks 파라미터보다 binwidth 파라미터가 편함.  
summary(diamonds$carat)
gg2+geom_histogram(binwidth=0.2,fill="orange")  #bin값에 따라 전혀 다른 모양의 히스토그램이 그려질 수 있음.
gg2+geom_histogram(aes(y=..count..),binwidth=0.2,fill="orange")  #y축의 기준을 ..count..로 재정의 할 수 있음.(데이터프레임의 변수와 혼용방지위한 표현법)
gg2+geom_histogram(aes(y=..ncount..),binwidth=0.2,fill="orange")  #표준화된 빈도를 y축으로 표현
gg2+geom_histogram(aes(y=..density..),binwidth=0.2,fill="orange")  #밀도를 y축으로 표현
gg2+geom_histogram(aes(y=..ndensity..),binwidth=0.2,fill="orange")  #표준화된 밀도를 y축으로 표현

#히스토그램 그룹별로 따로 그래프 그리기
gg2+geom_histogram(binwidth=0.2,fill="orange")+facet_grid(color~.)  #y축을 자르라는 얘기임.
gg2+geom_histogram(binwidth=0.2,fill="orange")+facet_grid(color~.,scales="free")  #y축 scale을 자유롭게 풀어줌.

#히스토그램 그룹별로 겹쳐서 보기 - 비교해야할 명목변수가 있다면 geom_histogram()이 hist()보다 좋음.
gg2+geom_histogram(aes(fill=color),binwidth=0.2)
gg2+geom_histogram(aes(fill=color),binwidth=0.2,alpha=0.5)  #alpha 파라미터는 투명도

##박스플롯
boxplot(height~bloodtype)
ggplot(Student,aes(x=bloodtype,y=height))+geom_boxplot()
ggplot(Student,aes(x=bloodtype,y=height))+geom_boxplot()+geom_point()

##산점도 그리기
gg3<-ggplot(Student,aes(x=weight,y=height))
gg3+geom_point() 
gg3+geom_point(aes(color=sex),size=7)  #성별 색깔 다르게, 점 크기 키움.
gg3+geom_point(aes(color=sex,shape=bloodtype),size=7)  #성별 색깔로 구분, 혈액형 모양으로 구분
gg3+geom_point(aes(color=height,shape=sex),size=7)  #성별 모양으로 구분, 색깔은 연속형 변수도 가능(모양은 불가!)
gg3+geom_point(aes(size=height,shape=sex),color="orange")  #size도 연속형 변수 가능
gg3+geom_point(aes(color=sex,shape=bloodtype),size=7,alpha=0.6)  #투명도 조절
gg3+geom_point(aes(color=sex),size=7)+geom_smooth(method="lm")  #회귀모델 추가
gg3+geom_point(aes(color=sex),size=7)+geom_text(aes(label=name))  #점에 이름 표시
gg3+geom_point(aes(color=sex),size=7)+geom_text(aes(label=name),vjust=2.0,color="black")  #이름 위치 조정

##theme()함수 - 배경컬러, 축컬러, 모양, 크기, 색깔 등 엄청나게 많은 디자인적 요소를 정할 수 있는 함수
#이 모든 것을 일일이 직접 입력할 수도 있지만, 잘 만들어진 테마를 사용하는 것도 좋은 방법임.
#ggplot2에서 제공하는 테마는 한정적이므로 ggthemes 패키지에서 추가적인 테마 제공
gg3+geom_point(aes(color=sex),size=7)+geom_text(aes(label=name),vjust=2.0,color="black")+
  theme_wsj()
gg3+geom_point(aes(color=sex),size=7)+geom_text(aes(label=name),vjust=2.0,color="black")+
  theme_wsj()+
  expand_limits(y=c(150,190))  #축조정

?theme()  #세부 기능을 익히려면 manual이나 참고자료 참조 - http://docs.ggplot2.org/current/theme.html
