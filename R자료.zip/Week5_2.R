mat1 <- matrix(c(1,2,3,4))  #기본적으로 열이 우선
mat1
mat2 <- matrix(c(1,2,3,4),nrow=2)  #열이 우선적으로 생김
mat2
mat3 <- matrix(c(1,2,3,4),nrow=2,byrow=T)  #행을 우선을 하려면 byrow사용
mat3
mat3[ ,1]  #모든 행의 1 열 값을 출력
mat3[1,]  #1행의 모든 열 값을 출력
mat3[1,1] #1행 1열의 값을 출력
dim(mat3)  #행과 열의수 차례로 반환

mat4 <- matrix(c(1:9),nrow=3,byrow=T)
mat4
mat4 <- rbind(mat4,c(11,12,13))  #마지막 행이 추가됨.
mat4
mat4 <- rbind(mat4,c(15,16,17,18)) ; mat4  #길이가 길 경우 경고메시지 나옴.

mat5 <- matrix(c("a","b","c","d"),nrow=2,byrow=T)
mat5
mat5 <- cbind(mat5,c('e','f'))  #새로운 열이 추가됨.
mat5
colnames(mat5) <- c('First','Second','Third')  #열이름 지정
mat5
rownames(mat5) <- c("James", "Rylee") #행이름 지정
mat5

array1 <- array(c(1:12), dim=c(4,3))  #matrix처럼 2차원 배열
array1
array2 <- array(c(1:12), dim=c(2,2,3))  #3차원 배열을 생성
array2
array2[1,1,3]  #x:1, y:1, z:3인 데이터를 조회

