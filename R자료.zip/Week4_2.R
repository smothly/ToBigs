for(i in 1:5) i^2  #i^2가 계산되지만 아무것도 저장되지 않음.
for(i in 1:5) print(i^2)  #i^2가 계산되어 프린트 되지만 값을 보는 목적 외에 나중에 이 값을 다시 사용할 수 없음.
ff<-NULL  #ff변수 지정
for(i in 1:5) ff[i] <- i^2  
print(ff) #ff라는 변수를 사용해 나중에 이 값을 다시 사용할 수 있게 됨.

mean(x = c(1,2,3))
x
mean(x <- c(1,2,3))
x

var1 <- "aaa"  #var1 이라는 변수(그릇)에 문자형 데이터 담기
var2 <- 111  #var2 라는 변수(그릇)에 숫자형 데이터 담기
var3 <- Sys.Date( )  #var3 이라는 변수(그릇)에 날짜형 데이터 담기
var4 <- c("a","b","c")  #여러 건의 데이터 한꺼번에 담기 (벡터 사용)
var1
var2
var3
var4
string1 <- "Very Easy R Programming"
string1
string2 <- "I'm James Seo "
string2
comp <- c(1,"2")
comp
class(comp)

num1 <- 1
num2 <- 2
num1 + num2
num1 <- 1   #숫자
char1 <- "a"  #문자
num1 + char1  #숫자+문자의 연산은 불가

seq1 <-1:5
seq1
seq2 <- "a":"f"  #문자는 연속적으로 할당 안됨.

# 연속적인 일 추가하기 
date1 <- seq(from=as.Date('2014-01-01'), to=as.Date('2014-01-31'),by="day") 
date1

# 월 추가하기
date2 <- seq(from=as.Date('2014-01-01'), to=as.Date('2014-05-31'),by='month')  
date2

# 년 추가하기
date3 <- seq(from=as.Date('2014-01-01'), to=as.Date('2020-05-31'),by='year')   
date3

objects( )
# 위와 같이 objects( ) 함수를 이용하면 생성되어 있는 변수를 보여줌. 단, .으로 시작하는 숨김 변수들은 objects( ) 함수를 기본값으로 사용할 경우에는 안보이고 objects(all.names=T) 라는 속성을 써줘야 조회가 됨.

string2
rm(string2)  #string2 변수를 삭제
string2
objects()
   
rm(list=ls( ))  #모든 변수들을 삭제
objects()