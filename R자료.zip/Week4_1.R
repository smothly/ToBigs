setwd("c:\\r_temp")  # 역슬래쉬 두 개 사용 (하나는 안됨 – Why?) 
getwd( )   # 현재 설정된 작업 디렉터리를 확인
setwd("c:/r_temp")  # 슬래쉬도 사용 가능
getwd( )

print(1+2)  #이렇게 print 안에 출력하고 싶은 내용 쓰면 됨.
1+2  #이렇게 해도 사실 print 명령이 생략된 것
print("a")  #문자를 출력할 때는 겹(or 홑)따옴표를 붙여야 함.
'a'  #그냥 문자만 입력해도 정상적으로 출력됨.
print(pi)  #소수점일 경우 총 7 자리로 출력
print(pi, digits=3)  #digits로 자리수 지정 가능
print(3,4)  #두 개를 출력했는데 한 개만 나옴.
print("a", "b")  #문자의 경우는 아예 에러가 남.

cat(1,":","a","\n",2,":","b")   #숫자와 문자 여러 개를 한꺼번에 출력

1;2;3  #각 명령을 세미콜론으로 구분
1+2 ; 2*3 ; 4/2  #세미콜론을 기준으로 순서대로 명령이 실행

1+2
1+2*3  #연산자의 우선순위에 따라 뒤의 * (곱하기)부터 연산
(1+2)*3  #만약 더하기부터 하려면 괄호 사용
10000  #0 이 4개 까지는 그대로 나옴.
100000  #0 이 5개부터는 e로 표시
1000000  #0이 6 개라서 결과에 1 * 10^6 으로 표시
1e2  #이 표현은 1 * 10^2 이라는 뜻이므로 100 이 나옴.
3e2  #3 * 10^2 이라는 뜻이므로 300 반환
3e-1  #3*10^-1
3e-2  #3*10^-2
"1" + "2"  #숫자처럼 보여도 사실은 문자!
as.numeric("1") + as.numeric("2")  #숫자로 강제로 변환 후 합산!

'First'  #문자(홑따옴표)
"Second"  #문자(겹따옴표)
First  #그냥 사용하면 변수 이름으로 인식되어 에러 발생

class("1")  #class 함수는 인자의 자료형을 반환
class(1)  #숫자형 데이터 검사

3 & 0  #3 & 0 의 뜻으로 거짓(FALSE)
3 & 1  #3 & 1 의 뜻으로 참 & 참이라서 참(TRUE)
3 & 2  #T&T는 T
3 | 0  #참 or 거짓 이라서 결과는 참(TRUE)
3 | 1  #참 or 참 이라서 결과는 참(TRUE)
!0  #거짓이 아닌 것이라서 참(TRUE)
!1  #참이 아닌 것이라서 거짓(FALSE)
!3  #참이 아닌 것이라서 거짓(FALSE)

aa <- NA  #aa 변수에 NA값 입력
bb <- NULL  #bb 변수는 초기화만 시켜둠.
print (aa) 
print (bb)  
print (cc)  #cc 변수가 정의가 되어있지 않아 에러발생
sum(1,NA,2)  #NA 를 더하니까 결과가 NA 로 출력
sum(1,NULL,2)  #NULL 값은 제외하고 나머지 값만 더해서 결과가 나옴.
sum(1,2,NA)  #NA 값이 연산 결과를 NA로 나오게 함.
sum(1,2,NA,na.rm=T) #na.rm=T 로 NA 값을 제거하고 계산

setwd("c:\\r_temp")
txt1 <- read.csv("factor_test.txt")
txt1
factor1 <- factor(txt1$blood)
factor1
summary(factor1)
sex1 <- factor(txt1$sex)
summary(sex1)

gender <- factor("m", c("m","f"))
gender
nlevels(gender)
levels(gender)
levels(gender)[1]
levels(gender)[2]
grade <- factor(c("A","B"), c("F","D", "C", "B","A"), ordered=TRUE)
grade

Sys.Date()  #대소문자 주의! 컴퓨터 운영상의 날짜만 보여주는 함수
Sys.time()  #대소문자 주의! 날짜와 시간까지 다 보여주는 함수
date( )  #미국식 날짜와 시간
as.Date('2014-11-01')  #홑따옴표 혹은 겹따옴표 사용
as.Date("2014/11/01") 
as.Date("01-11-2014")  #의도하지 않은 날짜 나옴.
as.Date("01-11-2014",format="%d-%m-%Y")  #날짜 형태를 지정
as.Date("2014년 11월 1일",format="%Y년 %m월  %d일")
as.Date("01112014",format="%d%m%Y")  #년도가 대문자 Y 사용.
as.Date("011114",format="%d%m%y")  #년도가 소문자 y 사용
as.Date(10,origin="2014-11-10")  #주어진 날짜기준으로 10일 후의 날짜
as.Date(-10,origin="2014-11-10")  #주어진 날짜 기준으로 10일 이전 날짜
as.Date("2014-11-30") - as.Date("2014-11-01") #날짜로 변경해서 계산
as.Date("2014-11-01") + 5
