print ("Hello World")
print (1)
3+4
seq (1:100)
print(
  "Hello World"
)
# 주석
help(print) #도움말 시스템 호출 ?print
help.search("print") #주어진 문자열이 포함된 문서를 검색 ??print