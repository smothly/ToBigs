list1 <- list(name='James Seo', address='Seoul', tel='010-8706-4712', pay=500)
list1
class(list1)
str(list1)
list1$name
list1[1]
list1[[1]]
class(list1[1])
class(list1[[1]])
list1["name"]
list1[["name"]]
list1[c(1,3)]
list1[[c(1,3)]]

list1$name <- c('James Seo', 100)  #다른 자료형 추가
list1$name
class(list1$name)
class(list1["name"])
list1$birth <- as.Date('1975-10-23')  #생일을 추가
list1$no.children <- 3  #자녀수 추가
list1$child.ages <- c(10, 7, 5)  #각 자녀에 대한 나이 추가
list1

list1$birth <- NULL  #birth 키/값 삭제
list1

no <- c(1,2,3,4)
name <- c('Apple','Peach','Banana','Grape')
price <- c(500,200,100,50)
qty <- c(5,2,4,7)
sales <- data.frame(NO=no,NAME=name,PRICE=price,QTY=qty)
sales

sales2 <- matrix(c(1,'Apple',500,5, 2,'Peach',200,2, 3,'Banana',100,4, 4,'Grape',50,7),nrow=4,byrow=T)
sales2
df1 <- data.frame(sales2)  #데이터프레임으로 변환
df1
names(df1) <- c('NO','NAME','PRICE','QTY')  #라벨명을 지정
df1

sales
sales$NAME
sales[1,3]
sales[1,]
sales[,3]
sales[c(1,2),]
sales[,c(1,2)]
sales[,c(1:3)]

subset(sales,QTY<5)
subset(sales,PRICE==200)  # =가 아님에 주의!  
subset(sales,NAME=="Apple")
