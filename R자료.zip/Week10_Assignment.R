##1. (p401)
#Q1
func_test1<-function(a,b){
  c<-a-b
  return(c)
} #첫번째 수 a에서 두번째 수b를 뺀 값 C를 출력한다.
func_test1(3,2)
func_test1(2,3)

#Q2
func_test2<-function(a,b){
  c<-a-b
  return(abs(c))
} #첫번째 수 a에서 두번째 수b를 뺀 값 C에서 절대값(abs)를 사용해서 c값을 무조건 양수로 출력한다.
func_test2(2,3)
func_test2(3,2)

##2. (p538)
hw<-data.frame("이름"=c('주시헌','최경우','이은주','허민성','홍미나'),"키"=c(168,176,167,174,169),"몸무게"=c(52,68,47,82,51))
hw

#Q1
apply(hw[2],2,mean) #열이름 키에 해당하는 값의 평균을 출력한다.
mean(hw$키)

#Q2
apply(hw[3],2,mean) #열이름 몸무게에 해당하는 값의 평균을 출력한다.

#Q3
apply(hw[2],2,sd) #열이름 키에 해당하는 값의 표준편차를 출력한다.
sd(hw$키)

#Q4
apply(hw[3],2,sd) #열이름 몸무게에 해당하는 값의 표준편차를 출력한다.

평균<-sapply(hw[c(2,3)],mean)
표준편차<-sapply(hw[-1],sd)
cc<-rbind(평균,표준편차)
cc
class(cc)

##3. (p394~395)
setwd("C:\\R_temp")
getwd()

#Q1
data1<-read.csv("data1.csv")
data1
apply(data1[-1],2,sum) #연령 열을 제외하고 데이터를 지닌 각 열에 대해서 합계를 구한다.
sapply(data1[-1],sum)
apply(data1[,-1],1,sum) #연령 열 값을 제외하고 데이터를 지닌 각 행에 대해서 합계를 구한다.

#Q2
#1)
data2<-read.csv("1-4호선승하차승객수.csv")
data2 #csv를 data2 변수로 저장한다.

#2)
tapply(data2$승차,data2$노선번호,sum) #tapply 이용 노선 번호별 승차 인원 수 합계 계산
tapply(data2$하차,data2$노선번호,sum) #tapply 이용 노선 번호별 하차 인원 수 합계 계산
apply(data2[c(3,4)],2,sum) #3,4번째 열 인 승차, 하차 열에 대한 각각의 인원수 합계를 계산
sapply(data2[,c(3,4)],sum)
aggregate(승차+하차~노선번호,data2,sum) #승차+하차 데이터 합계를 노선변호 별로 계산한다.
aggregate(승차~노선번호,data2,sum) #승차 데이터 합계를 노선변호 별로 계산한다.
aggregate(하차~노선번호,data2,sum) #하차 데이터 합계를 노선변호 별로 계산한다.
