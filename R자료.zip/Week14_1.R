setwd("C:/c_temp")
getwd()

Student<-read.csv("example_studentlist.csv")
str(Student)
View(Student)
attach(Student)  #생성한 Student 데이터프레임을 메모리에 올려줌으로써 각 칼럼명을 변수명 형태로 사용가능하게 해줌!
#attach() 사용하지 않을 경우, 필드명 사용시 반드시 “Student$age”와 같은 형태로 적어주어야 함! 
age
##plot함수 사용 그래프 그리기 - plot()함수가 모든 그래프 함수의 기본!
plot(age)  #변수 한 개를 넣으면 y축의 값으로 인식!
plot(height,weight)  #변수 두 개를 넣으면 각각 x축과 y축의 값으로 차례대로 인식! - 이런 모양의 그래프를 산점도(scatter plot)라고 함.
plot(weight~height)  #이 것은 "정규식 표현", 위 줄의 표현은 "데카르트식 표현"이라고 함.
sex
height
plot(height,sex)  #y축에 명목형 변수가 들어간 경우
height
sex
plot(sex,height)  #x축에 명목형 변수가 들어간 경우

plot(sex,height,xlab="sex",ylab="height")  #xlab 및 ylab 파라미터는 x,y축에 사용할 축제목 지정!

Student2<-data.frame(height,weight)
Student2
plot(Student2)  #두 변수로 이뤄진 데이터프레임을 넣을 경우

Student3<-cbind(Student2,age)

Student3
plot(Student3)  #세 변수로 이뤄진 데이터프레임을 넣을 경우

plot(Student)  #모든 변수들로 이뤄진 데이터프레임 자체를 넣을 경우
cor(height,weight)  # 두 변수간 상관 계수

#Q2) 추세선 삽입
weight
height
plot(weight~height)  #산점도
weight
height
m<-lm(weight~height, data=Student2)  #회귀분석
abline(m)  #추세선
m  #기울기 및 y절편 해석

##속성별 plot 그래프 그리기!
#키와 몸무게 그래프에서 점의 종류로 남자와 여자를 별도로 표시하고자 한다면?
plot(height,weight)
sex
as.integer(sex)
plot(height,weight,pch=as.integer(sex))  #pch 파라미터는 점의 종류(모양)를 나타냄.
legend("topleft",c("남","여"),pch=c(1,2))  #1은 남자, 2는 여자(pch에서 1은 동그라미 2는 세모 모양으로 이미 약속되어 있음.)로 주석추가하기!

weight
height
sex
coplot(weight~height | sex)  #coplot()는 조건화 그래프라 불리며 이 함수는 정규식 표현으로만 사용 가능!

##제목달기, 축이름 달기, 축한계 지정 등[교과서 449~450페이지 표 참조!!!]
plot(height,weight)
plot(height,weight,ann=F)  #"ann=F"를 사용하면 그래프에 아무 레이블(이름)도 나타나지 않음.
plot(height,weight,main="키와 몸무게 산포도") # 그래프 제목
plot(height,weight,xlab="키",ylab="몸무게") # 축제목
plot(height,weight,main="키와 몸무게 산포도",xlab="키",ylab="몸무게")
grid()  #격자(눈금) 표현
heightMean<-mean(height)
heightMean

abline(v=heightMean, col="red")  #키의 평균값 세로선 빨간색으로 추가

#Q3) 몸무게의 평균값 가로선을 파란색으로 추가하려면?
weightMean<-mean(weight)
abline(h=weightMean, col="blue")

#Q4) x축의 한계를 140~200으로, y축의 한계를 30~100으로 하려면? (Hint: xlim, ylim 파라미터 사용)
plot(height,weight,main="키와 몸무게 산포도",xlab="키",ylab="몸무게", xlim=c(140,200),ylim=c(30,100))

#Q5) 완성한 그래프를 저장하기 위한 방법은?
#(1)"Export"탭 사용
#(2)
png("키몸무게산포도.png")
plot(height,weight,main="키와 몸무게 산포도",xlab="키",ylab="몸무게")
dev.off()

##저수준 그래픽 함수 - 그래프 타입, 선의 모양 등
plot(height,weight)  
plot(height,weight, type="p")  #기본 점모양
plot(height,weight, type="l",lty=1, col="red")  #선모양 / 기본 실선 #lty라인타입
plot(height,weight, type="b",lty=2, col="blue")  #점과 선모양 / 대쉬선
plot(height,weight, type="o",lty=3, col="green")  #점과 선 중첩 / 점선

##그래프 중첩 그리기
plot(height,weight, type="p")  #기본 점모양
lines(height,weight, type="l",lty=2, col="red")  #plot 대신 lines함수 사용해서 중첩
