install.packages("XML")
library(XML)
pop <- 'http://www.worldometers.info/world-population/'
pop
pop_table <- readHTMLTable(pop)
length(pop_table)
pop_table <- readHTMLTable(pop)[[4]] # 위 표는 html 페이지에서 4번째 테이블
pop_table
pop_table[,c(2,3)]  #필요한 컬럼 부분만 가져옴. 

data()
data(iris)
iris
head(iris)
str(iris)
subset(iris, Sepal.Length>7.0)[, c(1,2,5)]

install.packages("googleVis")
library(googleVis)
data(Fruits)
Fruits
Fruits1<- gvisMotionChart(Fruits, idvar="Fruit", timevar="Year")
plot(Fruits1)

print(1,2)
cat(1,2)
a<-1:10
b<-11:15
c<-c("a","b","c","d","e")
print(a,b)
print(a,c)
print(b,c)
cat(a,b)
cat(a,c)
cat(b,c)
d<-print(a,b)
e<-cat(a,b)
class(d)
class(e)

a<-1:10
b<-11:15
c<-c("a","b","c","d","e")
d<-print(a,b)
e<-cat(a,b)
save(a,b,c,d,file="save_test.RData")
load("save_test.RData")
rm(list=ls())
load("save_test.RData")

fruits <- read.table('fruits.txt')
fruits
fruits <- read.table('fruits.txt', header=T); fruits
new<-data.frame(no=5,name="grape",price= 350,qty=10)
fruits_new <- rbind(fruits, new)
fruits_new
write.table(fruits_new,"fruits_new.txt")
fruits_new2 <- read.table('fruits_new.txt')
fruits_new2

write.csv(fruits_new,"fruits_new.csv")
fruits_new3 <- read.csv('fruits_new.csv')
fruits_new3
write.csv(fruits_new, "fruits_new.csv", row.names=F)
fruits_new3 <- read.csv('fruits_new.csv')
fruits_new3