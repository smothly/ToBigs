##데이터 분리 함수
install.packages("googleVis")
library(googleVis)
Fruits
str(Fruits)

##split함수
split(Fruits, Fruits$Fruit)
aa<-split(Fruits, Fruits$Fruit)
class(aa)

lapply(aa,mean)
lapply(split(Fruits$Sales, Fruits$Fruit), mean)
sapply(split(Fruits$Sales, Fruits$Fruit), mean)
class(lapply(split(Fruits$Sales, Fruits$Fruit), mean))
class(sapply(split(Fruits$Sales, Fruits$Fruit), mean))

#Q1) tapply 사용 tapply()를 사용하여 sapply(split(Fruits$Sales, Fruits$Fruit), mean)과 비슷한 결과를 나타내려면?
sapply(split(Fruits$Sales, Fruits$Fruit), mean)

tapply(Fruits$Sales, Fruits$Fruit, mean)
class(tapply(Fruits$Sales, Fruits$Fruit, mean))
split(Fruits$Sales, Fruits$Fruit)
sapply(split(Fruits$Sales, Fruits$Fruit),mean)
class(sapply(split(Fruits$Sales, Fruits$Fruit),mean))

#Q2) aggregate() 사용 sapply(split(Fruits$Sales, Fruits$Fruit), mean)과 비슷한 결과
sapply(split(Fruits$Sales, Fruits$Fruit), mean)

aggregate(Sales~Fruit,Fruits,mean)

class(aggregate(Sales~Fruit,Fruits,mean))

##subset함수
Fruits
subset(Fruits, Year==2010)
subset(Fruits, Sales<100 & Profit>=10)
subset(Fruits, Fruit=="Apples" | Year>=2009)

subset(Fruits, select=c(Fruit, Year, Location))
subset(Fruits, select=c(-Profit, -Date))
subset(Fruits, select=-c(Profit, Date))
subset(Fruits, Year==2010, select=c(Fruit, Sales, Year))

#Q3)
Fruits[c(1:3)]
Fruits[,c(1:3)]
Fruits[-c(6,7)]
split(Fruits,Fruits$Year)
split(Fruits,Fruits$Year)[[3]]
split(Fruits,Fruits$Year)[[3]][c(1,4,2)]
class(split(Fruits,Fruits$Year)[[3]][c(1,4,2)])

##데이터 정렬 함수
a<-c(20,11,33,50,47)
sort(a)
sort(a, decreasing=TRUE)
a

b<-Fruits$Sales
b
sort(b)
sort(b, decreasing=TRUE)

a
order(a)
order(a, decreasing=TRUE)
order(-a)
a[order(a)]
sort(a)

Fruits
Fruits$Profit
bb<-Fruits$Profit
order(bb)
order(Fruits$Profit)
Fruits[order(Fruits$Profit),]
Fruits[order(Fruits$Profit,Fruits$Year),]

#Q4) Fruits 데이터 셋을 Date 기준으로 내림차순, Sales 기준으로 내림차순으로 정렬하려면? 
# Data 기준으로 내림차순, Sales 기준으로 오름차순으로 정렬하려면?
Fruits

order(Fruits$Date, decreasing=T)

Fruits[order(Fruits$Date, decreasing=T),] #답

order(Fruits$Date, Fruits$Sales, decreasing=T)

Fruits[order(Fruits$Date, Fruits$Sales, decreasing=T),] #답

## 간단하게...
Fruits[order(Fruits$Date, -Fruits$Sales, decreasing=T),]

## 더 어렵게...
order(Fruits$Sales,decreasing = T)
Fruits[order(Fruits$Date, order(Fruits$Sales,decreasing = T), decreasing=T),] 

## dplyr 패키지 사용하면 간단하게 해결!