install.packages("dplyr")
library(dplyr)
setwd("C:/R_temp")
getwd()
#1
movie<-read.csv("MoviePerformance.csv")
movie
#2
movie1<-na.omit(movie)
movie1
#3
movie2<-subset(movie1,Users>=100000)
movie2
#4
movie3<-subset(movie2,select=c(1,2,4,7,8,9))
movie3
#5
movie4<-mutate(movie3,BPSFirst=BoxOfficeFirst/ScreenFirst)
movie4
#6
movie4 %>%
  group_by(Grade,Genre) %>%
  summarise(BO_Mean=mean(BoxOffice),BO_Min=min(BoxOffice),BO_Max=max(BoxOffice))
#7
aa<-aggregate(BoxOffice~Grade+Genre,movie4,mean)
bb<-aggregate(BoxOffice~Grade+Genre,movie4,min)
cc<-aggregate(BoxOffice~Grade+Genre,movie4,max)
dd<-cbind(aa,bb[3],cc[3])
names(dd)<-c("Grade","Genre","BO_Mean","BO_Min","BO_Max")
dd[order(dd$Grade,dd$Genre),]

##8
install.packages("googleVis")
library(googleVis)
attach(Fruits)

#8-1
Fruits
Fruits_2<-filter(Fruits,Expenses>80)
Fruits_2

#8-2
Fruits_3<-filter(Fruits, Expenses>90, Sales>90)
Fruits_3

#8-3
Fruits_4<-filter(Fruits, Expenses>90 | Sales>80)
Fruits_4

#8-4
Fruits_5<-filter(Fruits, Expenses==79 | Expenses==91)
Fruits_5

Fruits_5<-filter(Fruits, Expenses %in% c(79,91))
Fruits_5

#8-5
select(Fruits, Fruit:Sales, -Location)

#8-6
Fruits %>% 
  group_by(Fruit) %>%
  summarise(average=sum(Sales, na.rm=T))

#8-7
Fruits %>% 
  group_by(Fruit) %>%
  summarise(Sales=sum(Sales),Profit=sum(Profit))

Fruits %>% 
  group_by(Fruit) %>%
  summarise_each(funs(sum), Sales, Profit)

##참고
Fruits %>% 
  group_by(Fruit) %>%
  summarise_each(funs(sum,mean), Sales, Profit)

Fruits %>% 
  group_by(Fruit) %>%
  summarise(Sales_sum=sum(Sales),Profit_sum=sum(Profit),Saels_mean=mean(Sales),Profit_mean=mean(Profit))
