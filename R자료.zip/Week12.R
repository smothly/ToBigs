##dplyr 패키지
install.packages("dplyr")
library(dplyr)
??dplyr

setwd("C:/c_temp")
getwd()
Sales<-read.csv("Sales.csv")
Sales
head(Sales)
View(Sales)

filter(Sales, Month==1,Store=="a")
filter(Sales, Month==1&Store=="a")
subset(Sales, Month==1&Store=="a")
subset(Sales, Month==1,Store=="a")
filter(Sales, Month==1 | Month==2)
slice(Sales, 1:10)
head(Sales, 10)
slice(Sales,3:8)

arrange(Sales,Store,Month,Day)
slice(arrange(Sales,Store,Month,Day),1:50)
slice(arrange(Sales,Store,desc(Month),Day),1:50)

#Q1) 요일을 월요일~일요일 순으로 나타내고 싶으면?
Sales

Sales$Day<-ordered(Sales$Day, levels=c("Mon","Tue","Wed","Thu","Fri","Sat","Sun"))
Sales$Day

Sales


select(Sales,Store,Month,Day,Sales_Freq)
slice(select(Sales,Store,Month,Day,Sales_Freq), 1:50)
slice(select(Sales,-Gender), 1:50)

distinct(select(Sales,Store))
distinct(select(Sales,Store,Month))
unique(select(Sales,Store))
unique(select(Sales,Store,Month))

mutate(Sales,New_Freq=signif(Sales_Freq, digits=3))
slice(mutate(Sales,New_Freq=signif(Sales_Freq, digits=3)),1:50)
transform(Sales,New_Freq=signif(Sales_Freq, digits=3))
slice(transform(Sales,New_Freq=signif(Sales_Freq, digits=3)),1:50)

summarise(Sales,mean(Sales_Freq))
summarize(Sales,Sales_Mean=mean(Sales_Freq))
class(summarise(Sales,mean(Sales_Freq)))
summarise(Sales,Max=max(Sales_Freq),Min=min(Sales_Freq),Mean=mean(Sales_Freq))

##chain "%>%" 사용
filter(Sales, Store=="a")  #a점포자료만 골라냄.
Sales %>% filter(Store=="a")  #Sales 데이터셋에서 a점포자료만 골라내어라!
Sales %>% 
  filter(Store=="a") %>%
  filter(Month==1)  #a점포 자료에서 1월자료만 골라내어라!

Sales %>%
  filter(Month==1) %>%
  summarise(Jan_Mean=mean(Sales_Freq),Jan_Sum=sum(Sales_Freq))  #1월 평균 및 합을 구하여라!

Sales %>%
  filter(Store=="a") %>%
  filter(Month==1) %>%
  summarise(Jan_Mean=mean(Sales_Freq),Jan_Sum=sum(Sales_Freq))  #a점포의 1월 평균 및 합을 구하여라!

Sales %>%
  group_by(Month) %>%
  summarise(Mon_Mean=mean(Sales_Freq),Mon_Sum=sum(Sales_Freq))  #매월 평균 및 합을 구하여라!

Sales %>%
  group_by(Month,Gender) %>%
  summarise(Mon_Mean=mean(Sales_Freq),Mon_Sum=sum(Sales_Freq))  #매월/성별 평균 및 합을 구하여라!

Sales %>%
  group_by(Month,Gender) %>%
  summarise(Mon_Mean=mean(Sales_Freq),Mon_Sum=sum(Sales_Freq)) %>%
  View  #매월/성별 평균 및 합을 구하여라! +View

##stringr 패키지
install.packages("stringr")
library(stringr)

fruits <- c('apple','Apple','banana','pineapple')
str_detect(fruits,"A")  #대문자 A가 있는 단어 찾기
str_detect(fruits,'^a')  #첫 글자가 소문자 a인 단어 찾기
str_detect(fruits,'e$')  #끝나는 글자가 소문자 e인 단어 찾기
str_detect(fruits,'^[aA]')  #시작하는 글자가 대문자 A나 소문자 a인 단어 찾기
str_detect(fruits,'[aA]')  #단어에 소문자 a나 대문자 A가 들어 있는 단어 찾기
str_detect(fruits,'ap')  #ap가 들어있는 단어 찾기
str_detect(fruits,ignore.case("a"))  #대소문자 구분없이 찾기

fruits
str_count(fruits,'a')  #주어진 단어에서 해당 글자가 몇 번 나오는 지 알려줌.
str_count(fruits,ignore.case('a'))

str_c("apple","banana")  #둘을 빈칸없이 이어붙임.
str_c(fruits)  #fruits 반환결과와 같음.
str_c(c("apple","banana"))
str_c("Fruits: ",fruits)
str_c(fruits," name is ",fruits)
str_c(fruits,collapse="")  #벡터의 모든 값들을 빈칸없이 이어붙여 하나의 값으로 만듦.
str_c(fruits,collapse="-")

#Q2) 빈칸을 두려면 방법은? paste()함수와의 차이점은?
str_c("apple","banana",sep=" ")
paste("apple","banana")
paste("apple","banana",sep="")
paste(fruits, " is delicious")
paste(fruits,collapse="")

#Q3)str_c(c("apple","banana")) 값은?
#str_c(c("a","b"),c("c","d")) 값은?


str_c(c("apple","banana"))
str_c(c("a","b"),c("c","d"))
str_c(c("a","b"),c("c","d"),collapse="_")

str_dup(fruits,3)  #주어진 문자열을 주어진 횟수만큼 반복
str_length('apple')  #주어진 문자열의 길이 출력
str_length(fruits)
length('apple')
length(fruits)

#Q4) str_dup(fruits,3)와 같은 결과를 str_c 함수를 써서 나타내려면?
str_dup(fruits,3)
str_c(fruits,fruits,fruits)

str_locate('apple','a')  #주어진 문자열에서 특정문자가 처음 및 나중에 나오는 위치 알려줌. 
str_locate(fruits,'a')
str_locate(fruits,'pp')
str_locate_all(fruits,'a')

str_replace('apple','p','*')  #변경전 문자를 변경후 문자로 바꿈.
str_replace('apple','p','**')
str_replace_all('apple','p','*') 

fruits <- str_c('apple','/','orange','/','banana')
fruits
str_split(fruits,"/")  #/ 기호를 기준으로 분리
aa<-str_split(fruits,"/")
class(aa)

#Q5) 리스트형 변수를 벡터형 변수로 바꾸려면?
bb<-aa[[1]]
bb

fruits
str_sub(fruits,start=1,end=3)  #주어진 문자열에서 지정된 길이만큼 문자를 잘라냄.
str_sub(fruits,start=6,end=9)
str_sub(fruits,start=-5)  # -는 뒤에서부터 시작

?str_sub
hw <- "Hadley Wickham"
hw
str_sub(hw, 1, 6)
str_sub(hw, end = 6)
str_sub(hw, 8, 14)
str_sub(hw, 8)
str_sub(hw, c(1, 8), c(6, 14))
# Negative indices
str_sub(hw, -1)
str_sub(hw, -7)
str_sub(hw, end = -7)

str_trim(' apple banana berry  ')  #문자열의 앞과 뒤에 공백이 있을 경우 제거
