##정규표현식
??`regular expression`

install.packages("stringr")
library(stringr)

char1 <- c('apple','Apple','APPLE','banana','grape')
grep('pp',char1)
grepl('pp',char1)
grep('pp',char1,value=T)
str_detect(char1,'pp')
str_extract(char1, "pp")
str_extract_all(char1, "pp")

char2 <- c('apple','banana')
grep(char2,char1)  #패턴을 2개 이상 주면 첫 번째 패턴만 사용
paste(char2,collapse='|')
grep(paste(char2,collapse='|'),char1,value=T) 
grep('^A',char1,value=T)  #^을 사용하여 대문자 'A' 로 시작하는 단어 찾기 
grep('e$',char1,value=T)  #$을 사용하여 소문자 'e' 로 끝나는 단어 찾기

char3 <- c('grape1','apple1','apple','orange','Apple')
grep('ap',char3,value=T)  #ap 가 포함된 단어 찾기
grep('[1-9]',char3,value=T)  #1~9사이숫자가 포함된 단어 찾기 - 모든 숫자는 "[0-9]"
grep('[[:upper:]]',char3,value=T)  #대문자가 포함된 단어 찾기
grep('[A-Z]',char3,value=T)  #대문자가 포함된 단어 찾기

cl <- colors()
cl
length(cl); cl[1:20]
grep("red",cl)
grepl("red",cl)
grep("red",cl, value=T)

nchar(char1)
nchar('James Seo')
nchar('서진수')
str_length(char1)
str_length('James Seo')
str_length('서진수')

paste('Seo','Jin','Su')  #공백있음
paste('Seo','Jin','Su',sep='')  #공백지움
paste('Seo','Jin','Su',sep='/')  #구분자 /로 지정
paste('I','\'m','Hungry')  #특수문자가 있을 경우 Escape character "\" 주의
paste("I'm","Hungry")
str_c("I","'m",'Hungry')

substr('abc123',3,3)
substr('abc123',3,4)
str_sub('abc123',3,3)
str_sub('abc123',3,4)

strsplit('2014/11/22',split='/')
str_split('2014/11/22',split='/')
strsplit('2014/11/22','/')
str_split('2014/11/22','/')

grep('-','010-8706-4712')  #grep으로는 위치를 찾을 수 없음.
regexpr('-','010-8706-4712')  #처음 나오는 '-' 문자 위치 찾기 
gregexpr('-','010-8706-4712')  #나오는 '-' 문자 위치 모두 찾기 
str_locate('010-8706-4712',"-")
str_locate_all('010-8706-4712',"-")

sub("p","*","apple")
gsub("p","*","apple")
str_replace("apple","p","*")
str_replace_all("apple","p","*")
