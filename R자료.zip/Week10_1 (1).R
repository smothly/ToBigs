#Q1) round(2.5)의 값은? 그 이유는?
round(2.5) # go to the even digit 짝수로 함유
#Q2) floor()와 trunc()의 차이점은?
#floor -> 내림 / trunc() -> 버림. 음수에서 차이
floor(-2.3)
trunc(-2.3)

#Q2) triple square root(삼중근)을 구하려면? 즉 8의 삼중근값은?
8^(1/3)

#Q3) vec2 값의 개수가 짝수일 때 median(vec2)는?
vec2 <- c('a','e','c','d')  #벡터에 문자를 할당
vec2
median(vec2)



##많이 사용되는 기본 함수들
round(3.5)  #반올림
round(3.49)
round(3.51)
round(pi)
round(pi, digits=3)
ceiling(3.5)  #올림
floor(3.5)  #내림 
trunc(3.5)  #버림

x1 <- seq(-2, 4, by = .5); x1
round(x1)  #IEEE룰 - "go to the even digit!"
ceiling(x1)
floor(x1)
trunc(x1)
X<-rbind(x1,round(x1),ceiling(x1),floor(x1),trunc(x1)) ; X
rownames(X) <- c("real","round","ceiling","floor","trunc") ; X

abs(1)  #절대값
abs(-1)
v1 <- -1
abs(v1)
v2 <- c(1,-2,3,-4)
abs(v2)

factorial(3)  #factorial함수 - 즉, 3! = 3*2*1
factorial(5)

choose(4,2)  #combination함수 - 즉, 4C2 = 4개 중 2개를 선택하는 방법의 수 
choose(5,1)
choose(5,2)

sqrt(2)  #루트값
log(5)  #자연로그 - 밑이 무리수 e인 로그
log2(5)  #밑이 2인 로그
log10(5) #밑이 10인 로그
exp(5)  #무리수e의 5승

##기본 통계관련 함수들
vec1 <- c(1,2,3,4,5,3,4,5,4,5,5,6,12,13)  #벡터에 숫자를 할당
vec2 <- c('a','e','c','d','b')  #벡터에 문자를 할당

max(vec1)  #최대값
max(vec2)  #문자의 최대값 - 알파벳은 크기의 순서가 있음
min(vec1)  #최소값
min(vec2)  #문자의 최소값
mean(vec1)  #평균값
mean(vec2)  #문자의 평균값 - 계산할 수 없어 NA반환
var(vec1)  #분산
sd(vec1)  #표준편차
sum(vec1)  #합계
median(vec1)  #중간값
median(vec2)
summary(vec1)  #자주쓰이는 함수 종합요약
summary(vec2)  #문자형 벡터의 summary
class(summary(vec1))
class(summary(vec2))
length(vec1)  #벡터의 길이 - 데이터 프레임의 경우는 필드명 수를 출력
length(vec2)

##Q5)R에서 최빈값을 구하는 방법은?
mode(vec1)  #mode는 데이터 타입의 일종! - 최빈값 함수가 아님!
table(vec1)
which.max(vec1)
which.max(table(vec1))
table(vec1)[which.max(table(vec1))]

## 다음 장에서 배울 사용자 정의 함수 사용하여 최빈값 구하기 
Mode <- function(x){
  y<-which.max(table(x))
  return(table(x)[y])
}
Mode(vec1)

##사용자 정의 함수
#입력값(인자)이 없는 경우
myfunct1 <- function( ) {  
            return(10)  
}
myfunct1  
myfunct1()

#인자가 하나인 경우
myfunct2 <- function(a) {  
            b <- a^2  #입력되는 값의 제곱 구하기
            return(b)
}
myfunct2(3)

#인자가 두개인 경우
myfunct3 <- function(a,b) {  
            c <- a*b  #입력되는 두 값을 곱하기
            return(c)
}
myfunct3(2,3)

#Q6) 분산을 구하는 함수 my.var()을 사용자 정의함수를 사용하여 나타내시오.
my.var <- function(x){
          m<-mean(x)
          return(sum((x-m)^2)/length(x))
}
my.var(c(1,2,3,4,5))
 
var(c(1,2,3,4,5))  #분산값이 다른 이유는???