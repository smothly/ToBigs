class House:
    def __init__(self,size,room):
        self.size=size
        self.room=room

        
